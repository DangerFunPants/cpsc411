#!/bin/tcsh

source ./stack_machine/stack_impl.csh
source "$1"